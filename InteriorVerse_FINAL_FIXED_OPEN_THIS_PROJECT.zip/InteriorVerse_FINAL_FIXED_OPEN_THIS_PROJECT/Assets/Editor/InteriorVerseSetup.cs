#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using InteriorVerseLite;

namespace InteriorVerseLite.Editor
{
    [InitializeOnLoad]
    public static class InteriorVerseSetup
    {
        private const string ScenePath = "Assets/InteriorVerse/Scenes/InteriorVerse.unity";
        private const string BackgroundFolder = "Assets/InteriorVerse/Background";
        private const string BackgroundJpg = BackgroundFolder + "/room.jpg";
        private const string BackgroundPng = BackgroundFolder + "/room.png";

        static InteriorVerseSetup()
        {
            EditorApplication.delayCall += () =>
            {
                if (!EditorApplication.isPlayingOrWillChangePlaymode &&
                    !EditorApplication.isCompiling && !EditorApplication.isUpdating &&
                    !File.Exists(ScenePath))
                    Generate();
            };
        }

        [MenuItem("InteriorVerse/Generate Clean Photo Design Scene")]
        public static void Generate()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Debug.LogError("Stop Play mode first, then choose InteriorVerse > Generate Clean Photo Design Scene.");
                return;
            }

            Directory.CreateDirectory("Assets/InteriorVerse/Scenes");
            Directory.CreateDirectory(BackgroundFolder);
            AssetDatabase.Refresh();

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "InteriorVerse";

            GameObject cameraGO = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
            cameraGO.tag = "MainCamera";
            cameraGO.transform.position = new Vector3(0, 0, -10);
            Camera cam = cameraGO.GetComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 5;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.12f,0.14f,0.16f);

            GameObject app = new GameObject("InteriorVerse Photo Designer");
            PhotoRoomDesigner designer = app.AddComponent<PhotoRoomDesigner>();
            designer.roomBackground = LoadRoomTexture();

            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorSceneManager.OpenScene(ScenePath);
            Debug.Log("InteriorVerse scene generated. Use InteriorVerse > Import Room Photo to choose a valid JPG/PNG.");
        }

        [MenuItem("InteriorVerse/Import Room Photo...")]
        public static void ImportRoomPhoto()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Debug.LogError("Stop Play mode before importing a room photo.");
                return;
            }

            string source = EditorUtility.OpenFilePanel("Choose a room photo", "", "jpg,jpeg,png");
            if (string.IsNullOrEmpty(source)) return;

            byte[] bytes = File.ReadAllBytes(source);
            Texture2D test = new Texture2D(2,2,TextureFormat.RGBA32,false);
            bool valid = test.LoadImage(bytes);
            Object.DestroyImmediate(test);
            if (!valid)
            {
                EditorUtility.DisplayDialog("Invalid image", "Unity could not decode this file. Choose a real JPG or PNG image.", "OK");
                return;
            }

            Directory.CreateDirectory(BackgroundFolder);
            string ext = Path.GetExtension(source).ToLowerInvariant();
            string destination = ext == ".png" ? BackgroundPng : BackgroundJpg;
            if (File.Exists(BackgroundJpg) && destination != BackgroundJpg) File.Delete(BackgroundJpg);
            if (File.Exists(BackgroundPng) && destination != BackgroundPng) File.Delete(BackgroundPng);
            File.Copy(source, destination, true);
            AssetDatabase.Refresh();

            Texture2D imported = AssetDatabase.LoadAssetAtPath<Texture2D>(destination);
            if (imported == null)
            {
                AssetDatabase.ImportAsset(destination, ImportAssetOptions.ForceUpdate);
                imported = AssetDatabase.LoadAssetAtPath<Texture2D>(destination);
            }

            PhotoRoomDesigner designer = UnityEngine.Object.FindAnyObjectByType<PhotoRoomDesigner>();
            if (designer == null)
            {
                EditorUtility.DisplayDialog("Scene not ready", "Generate the InteriorVerse scene first.", "OK");
                return;
            }
            Undo.RecordObject(designer, "Set room background");
            designer.roomBackground = imported;
            EditorUtility.SetDirty(designer);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            EditorSceneManager.SaveScene(SceneManager.GetActiveScene());
            Debug.Log("Room photo imported and assigned: " + destination);
        }

        [MenuItem("InteriorVerse/Reload Room Photo From Folder")]
        public static void ReloadRoomPhoto()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Debug.LogError("Stop Play mode before reloading the room photo.");
                return;
            }
            AssetDatabase.Refresh();
            PhotoRoomDesigner designer = UnityEngine.Object.FindAnyObjectByType<PhotoRoomDesigner>();
            if (designer == null)
            {
                EditorUtility.DisplayDialog("Scene not ready", "Open the InteriorVerse scene first.", "OK");
                return;
            }
            Texture2D texture = LoadRoomTexture();
            Undo.RecordObject(designer, "Reload room background");
            designer.roomBackground = texture;
            EditorUtility.SetDirty(designer);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            EditorSceneManager.SaveScene(SceneManager.GetActiveScene());
            Debug.Log(texture == null ? "No valid room.jpg/room.png found; using plain background." : "Room background reloaded.");
        }

        private static Texture2D LoadRoomTexture()
        {
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(BackgroundJpg);
            if (texture == null) texture = AssetDatabase.LoadAssetAtPath<Texture2D>(BackgroundPng);
            return texture;
        }
    }
}
#endif
