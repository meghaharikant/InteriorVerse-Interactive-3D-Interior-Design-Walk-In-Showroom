
#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class InteriorVerseWalkInShowroomSetup
{
    private const string ScenePath = "Assets/InteriorVerse/Scenes/InteriorVerse_WalkInShowroom.unity";

    [MenuItem("InteriorVerse/Build Unity 6 Walk-in Showroom")]
    public static void Build()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorUtility.DisplayDialog("Stop Play Mode", "Stop Play Mode before generating the showroom.", "OK");
            return;
        }
        Directory.CreateDirectory("Assets/InteriorVerse/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "InteriorVerse_WalkInShowroom";

        var player = new GameObject("Player / Walk Controller");
        player.transform.position = new Vector3(0, 0, 4.7f);
        // Face into the room; the rear wall and furniture are at negative Z.
        player.transform.rotation = Quaternion.Euler(0, 180, 0);
        var camObj = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        camObj.tag = "MainCamera";
        camObj.transform.SetParent(player.transform, false);
        camObj.transform.localPosition = new Vector3(0, 1.7f, 0);
        camObj.transform.localRotation = Quaternion.identity;
        var cam = camObj.GetComponent<Camera>();
        cam.fieldOfView = 72;
        cam.nearClipPlane = .1f;
        cam.farClipPlane = 100;
        cam.clearFlags = CameraClearFlags.Skybox;
        player.AddComponent<InteriorVerseWalkInShowroom>().playerCamera = cam;

        var floorLight = new GameObject("Soft fill light");
        var light = floorLight.AddComponent<Light>();
        light.type = LightType.Point;
        light.intensity = 4.5f;
        light.range = 12;
        light.color = new Color(1f, .83f, .64f);
        floorLight.transform.position = new Vector3(0, 3.4f, 0);

        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorSceneManager.OpenScene(ScenePath);
        Selection.activeGameObject = player;
        EditorUtility.DisplayDialog("InteriorVerse Ready",
            "Walk-in showroom scene created and added to Build Settings. Press Play to explore. Right-click in the Game view and move the mouse to look around; use WASD or arrow keys to walk. Use the on-screen room and lighting buttons.",
            "Start Exploring");
        Debug.Log("InteriorVerse Unity 6 walk-in showroom generated: " + ScenePath);
    }
}
#endif
