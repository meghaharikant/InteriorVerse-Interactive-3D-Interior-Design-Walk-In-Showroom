Unity-native walk-in showroom scripts. In Unity 6 use InteriorVerse > Build Unity 6 Walk-in Showroom.
