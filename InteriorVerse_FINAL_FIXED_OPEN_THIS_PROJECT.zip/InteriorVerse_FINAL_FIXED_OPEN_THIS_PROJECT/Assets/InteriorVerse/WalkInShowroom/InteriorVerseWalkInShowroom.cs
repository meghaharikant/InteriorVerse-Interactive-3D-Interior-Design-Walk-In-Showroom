
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class InteriorVerseWalkInShowroom : MonoBehaviour
{
    public Camera playerCamera;
    public float moveSpeed = 3.6f;
    public float mouseSensitivity = 2.0f;
    private float pitch;
    private bool lookEnabled;
    private bool warmLight;
    private string currentRoom = "Living Room";
    private Transform roomRoot;
    private Light sunLight;
    private Text infoText;
    private Text roomTitle;
    private Text selectedText;
    private readonly List<GameObject> products = new List<GameObject>();
    private Material wallMat, floorMat, woodMat, creamMat, greenMat, leatherMat, metalMat, tileMat, whiteMat, glassMat;
    private GameObject selectedProduct;

    void Start()
    {
        if (!playerCamera) playerCamera = Camera.main;
        if (!playerCamera)
        {
            var camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            playerCamera = camObj.AddComponent<Camera>();
            camObj.AddComponent<AudioListener>();
        }
        playerCamera.transform.position = new Vector3(0, 1.7f, 4.7f);
        playerCamera.transform.rotation = Quaternion.identity;
        CreateMaterials();
        CreateLighting();
        CreateUI();
        BuildRoom("Living Room");
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void Update()
    {
        if (playerCamera == null) return;
        if (Input.GetMouseButtonDown(1)) { lookEnabled = true; Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
        if (Input.GetKeyDown(KeyCode.Escape)) { lookEnabled = false; Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
        if (lookEnabled)
        {
            transform.Rotate(Vector3.up, Input.GetAxis("Mouse X") * mouseSensitivity, Space.World);
            pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
            pitch = Mathf.Clamp(pitch, -75, 75);
            playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0, 0);
        }
        float x = 0, z = 0;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) z += 1;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) z -= 1;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) x -= 1;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) x += 1;
        Vector3 move = (transform.forward * z + transform.right * x).normalized * moveSpeed * Time.deltaTime;
        Vector3 next = transform.position + move;
        next.x = Mathf.Clamp(next.x, -5.15f, 5.15f);
        next.z = Mathf.Clamp(next.z, -5.15f, 5.15f);
        transform.position = new Vector3(next.x, 0, next.z);
        if (Input.GetMouseButtonDown(0)) SelectFromView();
    }

    void CreateMaterials()
    {
        wallMat = MakeMat("Warm ivory plaster", new Color(.78f,.75f,.68f), .92f);
        floorMat = MakeMat("Natural oak flooring", new Color(.37f,.23f,.13f), .62f);
        woodMat = MakeMat("Walnut wood", new Color(.27f,.15f,.08f), .48f);
        creamMat = MakeMat("Linen cream", new Color(.82f,.75f,.62f), .86f);
        greenMat = MakeMat("Sage velvet", new Color(.20f,.34f,.27f), .88f);
        leatherMat = MakeMat("Cognac leather", new Color(.42f,.19f,.09f), .44f);
        metalMat = MakeMat("Brushed brass", new Color(.60f,.43f,.17f), .26f, .72f);
        tileMat = MakeMat("Bathroom porcelain tile", new Color(.48f,.59f,.58f), .28f);
        whiteMat = MakeMat("Gloss ceramic", new Color(.88f,.87f,.81f), .22f);
        glassMat = MakeMat("Shower glass", new Color(.45f,.70f,.72f,.34f), .12f);
    }
    Material MakeMat(string n, Color c, float rough, float metal=0)
    {
        Shader s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null) s = Shader.Find("Standard");
        var m = new Material(s); m.name=n; m.color=c;
        // Procedural tileable surface maps add material detail without external asset downloads.
        Texture2D surface = CreateSurfaceTexture(n, c);
        if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", surface);
        if (m.HasProperty("_MainTex")) m.SetTexture("_MainTex", surface);
        m.mainTexture = surface;
        m.mainTextureScale = new Vector2(2.5f, 2.5f);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 1f-rough);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metal);
        if (m.HasProperty("_Surface") && c.a < .99f) { m.SetFloat("_Surface",1); m.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha); m.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha); m.SetInt("_ZWrite",0); m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT"); }
        return m;
    }
    Texture2D CreateSurfaceTexture(string materialName, Color baseColor)
    {
        const int size = 128;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, true);
        tex.name = materialName + " procedural texture";
        tex.wrapMode = TextureWrapMode.Repeat;
        tex.filterMode = FilterMode.Trilinear;
        int seed = materialName.GetHashCode();
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float noise = Mathf.PerlinNoise((x + seed % 37) * .075f, (y + seed % 53) * .075f) - .5f;
                float grain = Mathf.Sin((x + Mathf.Sin(y * .08f) * 8f) * .38f) * .035f;
                float variation = noise * .10f;
                string n = materialName.ToLowerInvariant();
                if (n.Contains("wood") || n.Contains("oak") || n.Contains("walnut")) variation += grain + Mathf.Sin(x * .08f + Mathf.Sin(y * .04f) * 3f) * .035f;
                else if (n.Contains("tile") || n.Contains("porcelain") || n.Contains("quartz")) variation += (Mathf.PerlinNoise(x * .12f, y * .12f) - .5f) * .045f;
                else if (n.Contains("velvet") || n.Contains("linen") || n.Contains("fabric") || n.Contains("rug")) variation += (Mathf.Sin(x * 1.7f) + Mathf.Sin(y * 1.7f)) * .012f;
                else if (n.Contains("leather")) variation += Mathf.Sin(x * .45f) * Mathf.Sin(y * .45f) * .025f;
                else if (n.Contains("plaster") || n.Contains("ivory")) variation += noise * .04f;
                float v = Mathf.Clamp(1f + variation, .78f, 1.22f);
                tex.SetPixel(x, y, new Color(Mathf.Clamp01(baseColor.r * v), Mathf.Clamp01(baseColor.g * v), Mathf.Clamp01(baseColor.b * v), baseColor.a));
            }
        }
        tex.Apply(true, true);
        return tex;
    }

    void CreateLighting()
    {
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(.55f,.64f,.72f);
        RenderSettings.ambientEquatorColor = new Color(.48f,.43f,.36f);
        RenderSettings.ambientGroundColor = new Color(.24f,.20f,.16f);
        RenderSettings.fog = true; RenderSettings.fogColor = new Color(.67f,.72f,.70f);
        RenderSettings.fogMode = FogMode.Exponential; RenderSettings.fogDensity = .012f;
        var sunObj = new GameObject("Sunlight - directional key light");
        sunLight = sunObj.AddComponent<Light>(); sunLight.type = LightType.Directional;
        sunLight.intensity = 1.25f; sunLight.color = new Color(1f,.88f,.72f);
        sunObj.transform.rotation = Quaternion.Euler(48,-32,0);
        sunLight.shadows = LightShadows.Soft;
    }
    void CreateUI()
    {
        if (FindObjectOfType<EventSystem>() == null) new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        var canvasObj = new GameObject("InteriorVerse Showroom UI", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObj.GetComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        var scaler=canvasObj.GetComponent<CanvasScaler>(); scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution=new Vector2(1600,900); scaler.matchWidthOrHeight=.5f;
        var top=Panel("Top Bar",canvas.transform,new Vector2(.5f,1),new Vector2(.5f,1),new Vector2(0,-16),new Vector2(920,74),new Color(.045f,.065f,.06f,.92f));
        roomTitle=Label(top.transform,"INTERIORVERSE  •  WALK-IN SHOWROOM",24,TextAnchor.MiddleLeft,new Vector2(0,0),new Vector2(1,1),new Vector2(20,0),new Vector2(-20,0),new Color(.91f,.78f,.52f));
        var left=Panel("Room Selector",canvas.transform,new Vector2(0,1),new Vector2(0,1),new Vector2(18,-112),new Vector2(260,286),new Color(.045f,.065f,.06f,.92f));
        Label(left.transform,"EXPLORE ROOMS",18,TextAnchor.MiddleLeft,new Vector2(0,1),new Vector2(1,1),new Vector2(14,-8),new Vector2(-14,-42),new Color(.91f,.78f,.52f));
        Button(left.transform,"Living Room",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-52),new Vector2(-12,-92),()=>BuildRoom("Living Room"));
        Button(left.transform,"Bedroom",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-98),new Vector2(-12,-138),()=>BuildRoom("Bedroom"));
        Button(left.transform,"Bathroom",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-144),new Vector2(-12,-184),()=>BuildRoom("Bathroom"));
        Button(left.transform,"Kitchen",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-190),new Vector2(-12,-230),()=>BuildRoom("Kitchen"));
        var right=Panel("Lighting Controls",canvas.transform,new Vector2(1,1),new Vector2(1,1),new Vector2(-18,-112),new Vector2(240,150),new Color(.045f,.065f,.06f,.92f));
        Label(right.transform,"LIGHTING MOOD",17,TextAnchor.MiddleCenter,new Vector2(0,1),new Vector2(1,1),new Vector2(10,-8),new Vector2(-10,-42),new Color(.91f,.78f,.52f));
        Button(right.transform,"Daylight",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-55),new Vector2(-12,-95),()=>SetLighting(false));
        Button(right.transform,"Warm Evening",new Vector2(0,1),new Vector2(1,1),new Vector2(12,-101),new Vector2(-12,-141),()=>SetLighting(true));
        var bottom=Panel("Instructions",canvas.transform,new Vector2(.5f,0),new Vector2(.5f,0),new Vector2(0,18),new Vector2(880,100),new Color(.045f,.065f,.06f,.92f));
        infoText=Label(bottom.transform,"WASD / ARROWS: walk  •  Right-click + mouse: look  •  Left-click furniture: inspect  •  ESC: release mouse",16,TextAnchor.MiddleCenter,new Vector2(0,0),new Vector2(1,1),new Vector2(12,0),new Vector2(-12,0),Color.white);
        var select=Panel("Product Details",canvas.transform,new Vector2(1,0),new Vector2(1,0),new Vector2(-18,132),new Vector2(280,100),new Color(.045f,.065f,.06f,.92f));
        selectedText=Label(select.transform,"PRODUCT DETAILS\nClick a furniture item.",15,TextAnchor.MiddleLeft,new Vector2(0,0),new Vector2(1,1),new Vector2(12,4),new Vector2(-12,-4),Color.white);
    }
    GameObject Panel(string n,Transform parent,Vector2 amin,Vector2 amax,Vector2 pos,Vector2 size,Color color)
    {
        var g=new GameObject(n,typeof(RectTransform),typeof(Image));g.transform.SetParent(parent,false);
        var r=g.GetComponent<RectTransform>();r.anchorMin=amin;r.anchorMax=amax;r.pivot=new Vector2((amin.x+amax.x)/2,(amin.y+amax.y)/2);r.anchoredPosition=pos;r.sizeDelta=size;
        g.GetComponent<Image>().color=color;return g;
    }
    Font UiFont()
    {
        // Unity 6 no longer exposes Arial.ttf as a built-in font.
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
    }

    Text Label(Transform parent,string txt,int size,TextAnchor align,Vector2 amin,Vector2 amax,Vector2 offMin,Vector2 offMax,Color color)
    {
        var g=new GameObject("Text",typeof(RectTransform),typeof(Text));g.transform.SetParent(parent,false);
        var r=g.GetComponent<RectTransform>();r.anchorMin=amin;r.anchorMax=amax;r.offsetMin=offMin;r.offsetMax=offMax;
        var t=g.GetComponent<Text>();t.text=txt;t.font=UiFont();t.fontSize=size;t.alignment=align;t.color=color;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Overflow;return t;
    }
    void Button(Transform parent,string text,Vector2 amin,Vector2 amax,Vector2 offMin,Vector2 offMax,UnityEngine.Events.UnityAction action)
    {
        var g=new GameObject(text+" Button",typeof(RectTransform),typeof(Image),typeof(Button));g.transform.SetParent(parent,false);
        var r=g.GetComponent<RectTransform>();r.anchorMin=amin;r.anchorMax=amax;
        // Normalize reversed Y offsets for top-anchored controls; otherwise height becomes negative.
        if (Mathf.Abs(amin.y - amax.y) < 0.0001f && offMin.y > offMax.y)
        {
            float lowY = offMax.y;
            float highY = offMin.y;
            offMin.y = lowY;
            offMax.y = highY;
        }
        r.offsetMin=offMin;r.offsetMax=offMax;
        var im=g.GetComponent<Image>();im.color=new Color(.20f,.29f,.24f,.98f);
        var b=g.GetComponent<Button>();b.targetGraphic=im;b.onClick.AddListener(action);
        Label(g.transform,text,16,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one,new Vector2(4,2),new Vector2(-4,-2),Color.white);
    }
    void BuildRoom(string roomName)
    {
        currentRoom=roomName;
        if(roomRoot) Destroy(roomRoot.gameObject);
        products.Clear();selectedProduct=null;
        roomRoot=new GameObject(roomName+" 3D Environment").transform;
        // Room shell: oak floor, plaster walls, ceiling, skirting and architectural window.
        MakeCube("Oak plank floor",new Vector3(0,-.12f,0),new Vector3(12,.24f,12),floorMat,false);
        MakeCube("Rear plaster wall",new Vector3(0,2.1f,-6),new Vector3(12,4.2f,.18f),wallMat,false);
        MakeCube("Left plaster wall",new Vector3(-6,2.1f,0),new Vector3(.18f,4.2f,12),wallMat,false);
        MakeCube("Right plaster wall",new Vector3(6,2.1f,0),new Vector3(.18f,4.2f,12),wallMat,false);
        MakeCube("Ceiling",new Vector3(0,4.25f,0),new Vector3(12,.15f,12),creamMat,false);
        MakeCube("Window frame",new Vector3(-2.8f,2.45f,-5.84f),new Vector3(2.5f,1.9f,.08f),whiteMat,false);
        MakeCube("Window daylight glass",new Vector3(-2.8f,2.45f,-5.78f),new Vector3(2.28f,1.68f,.025f),MakeMat("Blue window glass",new Color(.34f,.62f,.72f),.12f),false);
        MakeCube("Window sill",new Vector3(-2.8f,1.48f,-5.68f),new Vector3(2.65f,.09f,.24f),whiteMat,false);
        MakeCube("Rear wall art canvas",new Vector3(1.1f,2.7f,-5.82f),new Vector3(1.25f,1.15f,.07f),MakeMat("Abstract art",new Color(.57f,.37f,.22f),.85f),false);
        MakeCube("Baseboard rear",new Vector3(0,.08f,-5.86f),new Vector3(11.7f,.16f,.08f),woodMat,false);
        AddArchitecturalDetails();
        if(roomName=="Living Room") BuildLiving();
        else if(roomName=="Bedroom") BuildBedroom();
        else if(roomName=="Bathroom") BuildBathroom();
        else BuildKitchen();
        if(roomTitle) roomTitle.text="INTERIORVERSE  •  "+roomName.ToUpper()+" DESIGN COLLECTION";
        if(infoText) infoText.text="WASD / ARROWS: walk  •  Right-click + mouse: look  •  Left-click furniture: inspect  •  ESC: release mouse";
        if(selectedText) selectedText.text="PRODUCT DETAILS\nClick a furniture item.";
        transform.position=new Vector3(0,0,4.7f); transform.rotation=Quaternion.Euler(0,180,0); pitch=0; if(playerCamera) playerCamera.transform.localRotation=Quaternion.identity;
    }
    GameObject MakeCube(string name,Vector3 pos,Vector3 scale,Material mat,bool product=true)
    {
        var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name=name;g.transform.SetParent(roomRoot,false);g.transform.position=pos;g.transform.localScale=scale;
        var r=g.GetComponent<Renderer>();r.sharedMaterial=mat;
        if(!product) { var c=g.GetComponent<Collider>();if(c) Destroy(c); }
        else { g.tag="Untagged";products.Add(g);var marker=g.AddComponent<ShowroomProduct>();marker.productName=name;marker.samplePrice=PriceFor(name); }
        return g;
    }
    int PriceFor(string n)
    {
        if(n.Contains("sofa")||n.Contains("Sofa"))return 34999;if(n.Contains("Bed"))return 27999;if(n.Contains("bathtub")||n.Contains("Bathtub"))return 48000;
        if(n.Contains("Vanity"))return 32000;if(n.Contains("Toilet"))return 14500;if(n.Contains("Cabinet"))return 12000;if(n.Contains("Coffee"))return 7999;
        if(n.Contains("Wardrobe"))return 24999;if(n.Contains("Dining"))return 32999;if(n.Contains("shower")||n.Contains("Shower"))return 5500;
        if(n.Contains("lamp")||n.Contains("Lamp"))return 4999;if(n.Contains("Table"))return 6999;return 4999;
    }
    void AddArchitecturalDetails()
    {
        // Window mullions, linen curtains, curtain rail and subtle wall trim.
        MakeCube("Window vertical mullion",new Vector3(-2.8f,2.45f,-5.72f),new Vector3(.045f,1.7f,.045f),whiteMat,false);
        MakeCube("Window horizontal mullion",new Vector3(-2.8f,2.45f,-5.72f),new Vector3(2.25f,.045f,.045f),whiteMat,false);
        MakeCube("Curtain rail",new Vector3(-2.8f,3.48f,-5.56f),new Vector3(3.05f,.055f,.055f),metalMat,false);
        Material curtainMat = MakeMat("Soft linen curtains", new Color(.72f,.65f,.53f), .96f);
        MakeCube("Left linen curtain",new Vector3(-4.18f,2.45f,-5.55f),new Vector3(.38f,1.95f,.12f),curtainMat,false);
        MakeCube("Right linen curtain",new Vector3(-1.42f,2.45f,-5.55f),new Vector3(.38f,1.95f,.12f),curtainMat,false);
        // Architectural skirting and restrained decorative wall panels.
        MakeCube("Left wall skirting",new Vector3(-5.86f,.08f,0),new Vector3(.08f,.16f,11.7f),woodMat,false);
        MakeCube("Right wall skirting",new Vector3(5.86f,.08f,0),new Vector3(.08f,.16f,11.7f),woodMat,false);
        MakeCube("Left wall decorative rail",new Vector3(-5.84f,1.15f,0),new Vector3(.045f,.045f,8.8f),creamMat,false);
        MakeCube("Right wall decorative rail",new Vector3(5.84f,1.15f,0),new Vector3(.045f,.045f,8.8f),creamMat,false);
        // Recessed-looking ceiling trim around the room perimeter.
        MakeCube("Ceiling rear trim",new Vector3(0,4.12f,-5.82f),new Vector3(11.65f,.07f,.10f),whiteMat,false);
        MakeCube("Ceiling left trim",new Vector3(-5.82f,4.12f,0),new Vector3(.10f,.07f,11.65f),whiteMat,false);
        MakeCube("Ceiling right trim",new Vector3(5.82f,4.12f,0),new Vector3(.10f,.07f,11.65f),whiteMat,false);
    }
    void BuildLiving()
    {
        Sofa(-1.2f,-2.1f,greenMat,"Sage velvet sofa"); Sofa(2.2f,-.1f,leatherMat,"Cognac leather sofa");
        MakeCube("Oak coffee table",new Vector3(.2f,.48f,-.15f),new Vector3(1.65f,.14f,.9f),woodMat);
        MakeCube("Woven area rug",new Vector3(.2f,.015f,-.2f),new Vector3(3.8f,.025f,2.8f),creamMat);
        MakeCube("Walnut sideboard",new Vector3(4.1f,.65f,-4.4f),new Vector3(1.6f,1.1f,.62f),woodMat);
        MakeCube("Brass floor lamp",new Vector3(-4.2f,1.2f,-1.1f),new Vector3(.12f,2.4f,.12f),metalMat);
        MakeCube("Cream lamp shade",new Vector3(-4.2f,2.45f,-1.1f),new Vector3(.45f,.28f,.45f),creamMat);
        Plant(4.4f,-3.6f);
    }
    void Sofa(float x,float z,Material m,string name)
    {
        MakeCube(name,new Vector3(x,.58f,z),new Vector3(2.6f,.65f,.92f),m);
        MakeCube(name+" backrest",new Vector3(x,.99f,z-.36f),new Vector3(2.6f,.8f,.24f),m);
        MakeCube(name+" left arm",new Vector3(x-1.18f,.78f,z),new Vector3(.28f,.62f,.95f),m);
        MakeCube(name+" right arm",new Vector3(x+1.18f,.78f,z),new Vector3(.28f,.62f,.95f),m);
        for(int i=-1;i<=1;i++)
        {
            MakeCube(name+" upholstered seat cushion",new Vector3(x+i*.78f,.92f,z+.08f),new Vector3(.72f,.12f,.68f),m);
            MakeCube(name+" back cushion",new Vector3(x+i*.78f,1.22f,z-.205f),new Vector3(.72f,.42f,.13f),m);
        }
        foreach(float lx in new float[]{x-1.02f,x+1.02f})
            foreach(float lz in new float[]{z-.32f,z+.32f})
                MakeCube(name+" tapered wood leg",new Vector3(lx,.20f,lz),new Vector3(.11f,.4f,.11f),woodMat,false);
        MakeCube(name+" accent pillow",new Vector3(x-.72f,1.22f,z+.03f),new Vector3(.42f,.36f,.18f),creamMat);
    }
    void Plant(float x,float z){MakeCube("Planter pot",new Vector3(x,.25f,z),new Vector3(.48f,.5f,.48f),woodMat);for(int i=0;i<5;i++)MakeCube("Indoor plant leaf",new Vector3(x+Mathf.Sin(i*1.25f)*.25f,.9f+(i%2)*.22f,z+Mathf.Cos(i*1.25f)*.22f),new Vector3(.22f,.75f,.18f),greenMat);}
    void BuildBedroom()
    {
        MakeCube("Queen bed base",new Vector3(0,.36f,-2),new Vector3(3.2f,.5f,2.5f),woodMat);
        MakeCube("Beige mattress",new Vector3(0,.68f,-2),new Vector3(3.05f,.25f,2.35f),creamMat);
        MakeCube("Upholstered headboard",new Vector3(0,1.35f,-3.18f),new Vector3(3.35f,1.4f,.2f),greenMat);
        MakeCube("Bed pillow",new Vector3(-.78f,.88f,-2.78f),new Vector3(.85f,.18f,.5f),whiteMat);
        MakeCube("Bed pillow",new Vector3(.78f,.88f,-2.78f),new Vector3(.85f,.18f,.5f),whiteMat);
        MakeCube("Textured bed runner",new Vector3(0,.84f,-1.15f),new Vector3(2.85f,.06f,.48f),greenMat);
        foreach(float bx in new float[]{-1.35f,1.35f}) foreach(float bz in new float[]{-2.95f,-1.05f}) MakeCube("Bed wooden leg",new Vector3(bx,.15f,bz),new Vector3(.16f,.3f,.16f),woodMat,false);
        MakeCube("Bedroom rug",new Vector3(0,.015f,-1),new Vector3(4.5f,.025f,3.2f),creamMat);
        foreach(float x in new float[]{-2.6f,2.6f}){MakeCube("Bedside table",new Vector3(x,.45f,-2),new Vector3(.78f,.8f,.68f),woodMat);MakeCube("Bedside lamp",new Vector3(x,1.05f,-2),new Vector3(.28f,.35f,.28f),metalMat);}
        MakeCube("Wardrobe",new Vector3(4.2f,1.5f,-4.4f),new Vector3(1.35f,3f,.85f),whiteMat);
    }
    void BuildBathroom()
    {
        MakeCube("Bathroom tiled floor",new Vector3(0,-.005f,0),new Vector3(11.7f,.025f,11.7f),tileMat);
        for(int x=-5;x<=5;x++)for(int z=-5;z<=5;z++)MakeCube("Decorative tile accent",new Vector3(x*1.02f,.012f,z*1.02f),new Vector3(.018f,.012f,.018f),whiteMat,false);
        MakeCube("Floating oak vanity",new Vector3(-2.7f,.95f,-3.7f),new Vector3(2.2f,.75f,.65f),woodMat);
        MakeCube("Ceramic basin",new Vector3(-2.7f,1.4f,-3.62f),new Vector3(1.25f,.2f,.56f),whiteMat);
        MakeCube("Brass basin faucet",new Vector3(-2.7f,1.65f,-3.38f),new Vector3(.08f,.42f,.08f),metalMat);
        MakeCube("Backlit mirror",new Vector3(-2.7f,2.45f,-5.82f),new Vector3(1.7f,1.3f,.06f),whiteMat);
        MakeCube("Walk-in shower glass",new Vector3(3.3f,1.65f,-3.65f),new Vector3(.07f,3.3f,3.5f),glassMat);
        MakeCube("Rainfall shower head",new Vector3(3.3f,3.1f,-4.5f),new Vector3(.55f,.08f,.42f),metalMat);
        MakeCube("Freestanding bathtub",new Vector3(2.65f,.42f,1.65f),new Vector3(2.35f,.78f,1.2f),whiteMat);
        MakeCube("Toilet cistern",new Vector3(-3.8f,.85f,1.35f),new Vector3(.65f,.9f,.3f),whiteMat);
        MakeCube("Toilet bowl",new Vector3(-3.8f,.38f,1.72f),new Vector3(.78f,.48f,.9f),whiteMat);
        MakeCube("Brass towel rail",new Vector3(-5.2f,1.55f,-1),new Vector3(.08f,1.8f,.15f),metalMat);
        MakeCube("Shower control plate",new Vector3(3.18f,1.25f,-2.55f),new Vector3(.08f,.42f,.3f),metalMat);
        MakeCube("Bath side panel",new Vector3(2.65f,.25f,2.22f),new Vector3(2.1f,.48f,.08f),tileMat);
        MakeCube("Bathroom niche shelf",new Vector3(1.25f,2.35f,-5.78f),new Vector3(1.05f,.08f,.12f),woodMat);
        MakeCube("Bathroom vanity stool",new Vector3(-1.2f,.28f,-2.5f),new Vector3(.7f,.5f,.55f),woodMat);
    }
    void BuildKitchen()
    {
        MakeCube("Kitchen island",new Vector3(0,.55f,-.3f),new Vector3(3.4f,1.1f,1.4f),woodMat);
        MakeCube("Quartz countertop",new Vector3(0,1.14f,-.3f),new Vector3(3.6f,.12f,1.55f),whiteMat);
        for(int i=-2;i<=2;i++){float x=i*2.1f;MakeCube("Kitchen cabinet",new Vector3(x,1.45f,-5.3f),new Vector3(1.8f,2.7f,.55f),whiteMat);MakeCube("Brass cabinet handle",new Vector3(x+.55f,1.45f,-4.99f),new Vector3(.05f,.42f,.05f),metalMat);}
        MakeCube("Induction cooktop",new Vector3(-.85f,1.22f,-.3f),new Vector3(1.0f,.05f,.7f),tileMat);
        MakeCube("Kitchen sink",new Vector3(.95f,1.22f,-.3f),new Vector3(.85f,.05f,.65f),metalMat);
        MakeCube("Kitchen faucet",new Vector3(.95f,1.48f,-.05f),new Vector3(.06f,.5f,.06f),metalMat);
        MakeCube("Built-in oven",new Vector3(-1.15f,.66f,-1.03f),new Vector3(.92f,.62f,.05f),metalMat);
        MakeCube("Oven dark glass",new Vector3(-1.15f,.66f,-.995f),new Vector3(.72f,.38f,.025f),MakeMat("Oven black glass",new Color(.045f,.055f,.055f),.12f,.18f));
        foreach(float x in new float[]{-1.25f,1.25f}){MakeCube("Bar stool seat",new Vector3(x,.68f,1.2f),new Vector3(.65f,.14f,.65f),leatherMat);MakeCube("Bar stool base",new Vector3(x,.32f,1.2f),new Vector3(.08f,.6f,.08f),metalMat);}
    }
    void SelectFromView()
    {
        Ray ray=playerCamera.ScreenPointToRay(new Vector3(Screen.width/2f,Screen.height/2f,0));
        if(Physics.Raycast(ray,out RaycastHit hit,8f))
        {
            var p=hit.collider.GetComponent<ShowroomProduct>();
            if(p){selectedProduct=hit.collider.gameObject;if(selectedText)selectedText.text=p.productName+"\nSample price: ₹"+p.samplePrice.ToString("N0")+"\nPremium showroom finish";if(infoText)infoText.text="Selected: "+p.productName+"  •  Sample price ₹"+p.samplePrice.ToString("N0");}
        }
    }
    void SetLighting(bool warm)
    {
        warmLight=warm;
        if(sunLight){sunLight.color=warm?new Color(1f,.57f,.32f):new Color(1f,.88f,.72f);sunLight.intensity=warm?.72f:1.25f;}
        RenderSettings.ambientSkyColor=warm?new Color(.34f,.25f,.22f):new Color(.55f,.64f,.72f);
        RenderSettings.ambientEquatorColor=warm?new Color(.38f,.25f,.18f):new Color(.48f,.43f,.36f);
        RenderSettings.fogColor=warm?new Color(.27f,.20f,.17f):new Color(.67f,.72f,.70f);
        if(infoText)infoText.text=warm?"Warm evening lighting enabled.":"Daylight lighting enabled.";
    }
}
