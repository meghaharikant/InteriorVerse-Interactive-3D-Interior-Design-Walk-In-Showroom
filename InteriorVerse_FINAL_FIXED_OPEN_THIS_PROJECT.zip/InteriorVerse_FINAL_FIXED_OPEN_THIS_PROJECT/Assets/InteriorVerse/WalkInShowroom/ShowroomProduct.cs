using UnityEngine;

public class ShowroomProduct : MonoBehaviour
{
    public string productName;
    public int samplePrice = 4999;
}
