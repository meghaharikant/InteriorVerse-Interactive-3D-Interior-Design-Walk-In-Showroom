using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace InteriorVerseLite
{
    public class PhotoRoomDesigner : MonoBehaviour
    {
        [Header("Background image asset (replace room image in Assets/InteriorVerse/Background)")]
        public Texture2D roomBackground;
        public Color panelColor = new Color(0.055f, 0.075f, 0.085f, 0.96f);

        private Canvas canvas;
        private RectTransform stage;
        private RawImage backgroundImage;
        private Text statusText;
        private Text budgetText;
        private readonly List<PlacedItem> items = new List<PlacedItem>();
        private readonly Stack<string> undoJson = new Stack<string>();
        private readonly Stack<string> redoJson = new Stack<string>();
        private int serial = 1;

        [Serializable]
        private class PlacedItem
        {
            public string id;
            public string label;
            public float x;
            public float y;
            public float scale;
            public float rotation;
            public int price;
        }

        [Serializable]
        private class ProjectData
        {
            public string projectName = "InteriorVerse Design";
            public List<PlacedItem> items = new List<PlacedItem>();
        }

        [Serializable]
        private class CatalogEntry
        {
            public string label;
            public string resource;
            public int price;
            public Vector2 size;
            public CatalogEntry(string label, string resource, int price, Vector2 size)
            { this.label = label; this.resource = resource; this.price = price; this.size = size; }
        }

        private readonly CatalogEntry[] catalog = new CatalogEntry[]
        {
            new CatalogEntry("Sofa — Sage", "sofa_sage", 34999, new Vector2(190,125)),
            new CatalogEntry("Sofa — Cognac", "sofa_cognac", 37999, new Vector2(190,135)),
            new CatalogEntry("Armchair — Charcoal", "armchair_charcoal", 12999, new Vector2(115,125)),
            new CatalogEntry("Coffee Table — Oak", "coffee_table_oak", 7999, new Vector2(150,105)),
            new CatalogEntry("Cupboard — Walnut", "sideboard_walnut", 18999, new Vector2(155,120)),
            new CatalogEntry("Plant — Monstera", "plant_monstera", 2499, new Vector2(100,145)),
            new CatalogEntry("Tree — Ficus", "tree_ficus", 3999, new Vector2(110,155)),
            new CatalogEntry("Rug — Woven", "rug_woven", 3999, new Vector2(190,125)),
            new CatalogEntry("Door — Oak", "door_oak", 8999, new Vector2(90,165)),
            new CatalogEntry("Floor Lamp — Brass", "lamp_brass", 4999, new Vector2(75,165)),
            new CatalogEntry("Bed — Beige", "bed_beige", 27999, new Vector2(190,155)),
            new CatalogEntry("Dining Set", "dining_set", 32999, new Vector2(190,165))
        };

        private void Start()
        {
            BuildUI();
            LoadAutosaveIfPresent();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F5)) SaveProject();
            if (Input.GetKeyDown(KeyCode.Delete)) DeleteSelected();
            if (Input.GetKeyDown(KeyCode.Z) && (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))) Undo();
            if (Input.GetKeyDown(KeyCode.Y) && (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))) Redo();
        }

        private void BuildUI()
        {
            GameObject canvasGO = new GameObject("InteriorVerse Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasGO.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasGO.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600, 900);
            scaler.matchWidthOrHeight = 0.5f;

            if (FindAnyObjectByType<EventSystem>() == null)
                new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

            GameObject stageGO = new GameObject("Room Photo Stage", typeof(RectTransform), typeof(Image));
            stageGO.transform.SetParent(canvasGO.transform, false);
            stage = stageGO.GetComponent<RectTransform>();
            stage.anchorMin = Vector2.zero;
            stage.anchorMax = Vector2.one;
            stage.offsetMin = Vector2.zero;
            stage.offsetMax = Vector2.zero;
            stageGO.GetComponent<Image>().color = new Color(0.12f, 0.14f, 0.16f);

            GameObject bgGO = new GameObject("Room Background Image", typeof(RectTransform), typeof(RawImage));
            bgGO.transform.SetParent(stageGO.transform, false);
            RectTransform bgRT = bgGO.GetComponent<RectTransform>();
            bgRT.anchorMin = Vector2.zero; bgRT.anchorMax = Vector2.one;
            bgRT.offsetMin = Vector2.zero; bgRT.offsetMax = Vector2.zero;
            backgroundImage = bgGO.GetComponent<RawImage>();
            backgroundImage.texture = roomBackground;
            backgroundImage.color = Color.white;
            backgroundImage.raycastTarget = false;
            backgroundImage.enabled = roomBackground != null;

            // Wider catalog with visible product thumbnails and readable labels.
            MakePanel("Left Catalog", canvasGO.transform, new Vector2(0, 0.5f), new Vector2(0, 0.5f),
                new Vector2(0, 0.5f), new Vector2(310, 720), new Vector2(12, 0), panelColor);
            Transform left = canvasGO.transform.Find("Left Catalog");
            AddText(left, "INTERIORVERSE", 26, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1), new Vector2(-24,42), new Vector2(12,-16), Color.white, TextAnchor.MiddleLeft);
            AddText(left, "PHOTO ROOM DESIGN STUDIO", 17, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1), new Vector2(-24,28), new Vector2(12,-52), new Color(0.48f,0.86f,0.72f), TextAnchor.MiddleLeft);
            AddText(left, "FURNITURE CATALOG — CLICK TO ADD", 18, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1), new Vector2(-24,30), new Vector2(12,-84), new Color(0.92f,0.95f,0.94f), TextAnchor.MiddleLeft);

            float catalogY = -120;
            for (int i = 0; i < catalog.Length; i++)
            {
                CatalogEntry entry = catalog[i];
                MakeCatalogButton(left, entry, new Vector2(12, catalogY), () => AddFurniture(entry));
                catalogY -= 48;
            }
            AddText(left, "Click a product to add it. Drag it to move.", 16, new Vector2(0,0), new Vector2(1,0), new Vector2(0,0),
                new Vector2(-24,34), new Vector2(12,8), new Color(0.82f,0.88f,0.86f), TextAnchor.MiddleLeft);

            // Wide tool panel; each control describes its exact action.
            MakePanel("Right Tools", canvasGO.transform, new Vector2(1,0.5f), new Vector2(1,0.5f),
                new Vector2(1,0.5f), new Vector2(330, 700), new Vector2(-12,0), panelColor);
            Transform right = canvasGO.transform.Find("Right Tools");
            AddText(right, "DESIGN TOOLS", 26, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1), new Vector2(-24,42), new Vector2(12,-16), Color.white, TextAnchor.MiddleCenter);
            AddText(right, "Select furniture first for rotate / size / delete.", 15, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1), new Vector2(-24,32), new Vector2(12,-50), new Color(0.82f,0.88f,0.86f), TextAnchor.MiddleCenter);
            float y = -90;
            ToolButton(right, "SAVE DESIGN — save JSON", () => SaveProject(), ref y, new Color(0.13f,0.44f,0.32f));
            ToolButton(right, "LOAD DESIGN — load JSON", () => LoadProject(), ref y, new Color(0.18f,0.31f,0.43f));
            ToolButton(right, "UNDO — reverse last change", () => Undo(), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "REDO — restore undone change", () => Redo(), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "ROTATE LEFT — 15°", () => RotateSelected(-15f), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "ROTATE RIGHT +15°", () => RotateSelected(15f), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "MAKE SMALLER — 15%", () => ScaleSelected(0.85f), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "MAKE LARGER +18%", () => ScaleSelected(1.18f), ref y, new Color(0.18f,0.22f,0.25f));
            ToolButton(right, "DELETE SELECTED ITEM", () => DeleteSelected(), ref y, new Color(0.48f,0.20f,0.18f));
            ToolButton(right, "EXPORT ITEM LIST — CSV", () => ExportCSV(), ref y, new Color(0.18f,0.31f,0.43f));
            ToolButton(right, "CLEAR ROOM — remove all", () => ClearDesign(), ref y, new Color(0.38f,0.22f,0.18f));
            budgetText = AddText(right, "ESTIMATED BUDGET: ₹0", 18, new Vector2(0,0), new Vector2(1,0), new Vector2(0,0),
                new Vector2(-24,44), new Vector2(12,8), new Color(0.50f,0.90f,0.70f), TextAnchor.MiddleCenter);

            GameObject statusPanel = MakePanel("Status Bar", canvasGO.transform, new Vector2(0.5f,0), new Vector2(0.5f,0),
                new Vector2(0.5f,0), new Vector2(620,38), new Vector2(0,12), new Color(0.055f,0.075f,0.085f,0.92f));
            statusText = AddText(statusPanel.transform, "Ready • Select furniture, then drag it to arrange your room photo", 12,
                Vector2.zero, Vector2.one, new Vector2(0.5f,0.5f), new Vector2(600,32), Vector2.zero,
                new Color(0.88f,0.92f,0.90f), TextAnchor.MiddleCenter);

            UpdateBudget();
        }

        private void AddFurniture(CatalogEntry entry)
        {
            PushUndo();
            string label = entry.label;
            GameObject go = new GameObject(label + " " + serial++, typeof(RectTransform), typeof(Image), typeof(DraggableFurniture));
            go.transform.SetParent(stage, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f,0.5f);
            rt.pivot = new Vector2(0.5f,0.5f);
            rt.anchoredPosition = new Vector2(UnityEngine.Random.Range(-180,180), UnityEngine.Random.Range(-110,110));
            rt.sizeDelta = entry.size;

            Image image = go.GetComponent<Image>();
            Texture2D texture = Resources.Load<Texture2D>("InteriorVerseFurniture/" + entry.resource);
            if (texture != null)
            {
                image.sprite = Sprite.Create(texture, new Rect(0,0,texture.width,texture.height), new Vector2(.5f,.5f), 100f);
                image.type = Image.Type.Simple;
                image.preserveAspect = true;
                image.color = Color.white;
            }
            else
            {
                image.color = FurnitureColor(label);
                Debug.LogWarning("Missing furniture image: Resources/InteriorVerseFurniture/" + entry.resource + ".png");
            }

            DraggableFurniture drag = go.GetComponent<DraggableFurniture>();
            drag.designer = this;
            drag.itemLabel = label;
            drag.price = entry.price;
            drag.SetSelected(true);

            items.Add(new PlacedItem { id = Guid.NewGuid().ToString("N"), label = label, x = rt.anchoredPosition.x, y = rt.anchoredPosition.y, scale = 1, rotation = 0, price = entry.price });
            statusText.text = label + " added • drag to place • use tools to rotate or resize";
            UpdateBudget();
        }

        private CatalogEntry FindCatalogEntry(string label, int price)
        {
            foreach (CatalogEntry entry in catalog)
                if (entry.label == label) return entry;
            return new CatalogEntry(label, "", price, new Vector2(130,100));
        }

        private Vector2 DefaultSize(string label)
        {
            if (label.Contains("Sofa")) return new Vector2(170, 75);
            if (label.Contains("Armchair")) return new Vector2(90, 85);
            if (label.Contains("Table")) return new Vector2(105, 65);
            if (label.Contains("Cupboard")) return new Vector2(95, 145);
            if (label.Contains("Plant") || label.Contains("Tree")) return new Vector2(65, 105);
            if (label.Contains("Rug")) return new Vector2(190, 105);
            if (label.Contains("Door")) return new Vector2(70, 145);
            if (label.Contains("Lamp")) return new Vector2(55, 125);
            if (label.Contains("Bed")) return new Vector2(165, 135);
            return new Vector2(100,80);
        }

        private Color FurnitureColor(string label)
        {
            if (label.Contains("Sofa")) return new Color(.19f,.42f,.33f,.94f);
            if (label.Contains("Armchair")) return new Color(.60f,.37f,.25f,.94f);
            if (label.Contains("Table")) return new Color(.38f,.24f,.14f,.94f);
            if (label.Contains("Cupboard") || label.Contains("Door")) return new Color(.35f,.21f,.13f,.94f);
            if (label.Contains("Plant") || label.Contains("Tree")) return new Color(.14f,.40f,.23f,.94f);
            if (label.Contains("Rug")) return new Color(.70f,.57f,.36f,.88f);
            if (label.Contains("Lamp")) return new Color(.72f,.66f,.42f,.94f);
            if (label.Contains("Bed")) return new Color(.66f,.70f,.74f,.94f);
            return new Color(.30f,.38f,.45f,.94f);
        }

        public void Select(DraggableFurniture item)
        {
            foreach (DraggableFurniture f in stage.GetComponentsInChildren<DraggableFurniture>())
                f.SetSelected(f == item);
            statusText.text = "Selected: " + item.itemLabel + " • drag to move, use rotate/size/delete tools";
        }

        public void UpdateItemPosition(DraggableFurniture item)
        {
            int idx = items.FindIndex(x => x.label == item.itemLabel);
            if (idx >= 0)
            {
                RectTransform rt = item.GetComponent<RectTransform>();
                items[idx].x = rt.anchoredPosition.x;
                items[idx].y = rt.anchoredPosition.y;
            }
        }

        private DraggableFurniture Selected()
        {
            foreach (DraggableFurniture f in stage.GetComponentsInChildren<DraggableFurniture>())
                if (f.IsSelected) return f;
            return null;
        }

        private void RotateSelected(float degrees)
        {
            var item = Selected();
            if (item == null) { statusText.text = "Select a furniture item first, then rotate it."; return; }
            PushUndo();
            item.transform.Rotate(0, 0, degrees);
            item.rotation = item.transform.eulerAngles.z;
            statusText.text = "Rotated " + item.itemLabel + " by " + degrees + " degrees";
            UpdateItemTransform(item);
        }

        private void ScaleSelected(float multiplier)
        {
            var item = Selected();
            if (item == null) { statusText.text = "Select a furniture item first, then resize it."; return; }
            PushUndo();
            item.transform.localScale = Vector3.one * Mathf.Clamp(item.transform.localScale.x * multiplier, 0.3f, 2.5f);
            item.scale = item.transform.localScale.x;
            statusText.text = "Resized " + item.itemLabel + " — scale " + item.scale.ToString("0.00");
            UpdateItemTransform(item);
        }

        private void UpdateItemTransform(DraggableFurniture item)
        {
            int idx = items.FindIndex(x => x.label == item.itemLabel);
            if (idx < 0) return;
            items[idx].scale = item.transform.localScale.x;
            items[idx].rotation = item.transform.eulerAngles.z;
            items[idx].x = item.GetComponent<RectTransform>().anchoredPosition.x;
            items[idx].y = item.GetComponent<RectTransform>().anchoredPosition.y;
        }

        private void DeleteSelected()
        {
            var item = Selected(); if (item == null) return;
            PushUndo();
            items.RemoveAll(x => x.label == item.itemLabel);
            Destroy(item.gameObject);
            UpdateBudget();
            statusText.text = "Selected furniture deleted";
        }

        private void ClearDesign()
        {
            PushUndo();
            foreach (var item in stage.GetComponentsInChildren<DraggableFurniture>())
                Destroy(item.gameObject);
            items.Clear();
            UpdateBudget();
            statusText.text = "Design cleared";
        }

        private void PushUndo()
        {
            undoJson.Push(UnityEngine.JsonUtility.ToJson(new ProjectData { items = new List<PlacedItem>(items) }));
            redoJson.Clear();
        }

        private void Undo()
        {
            if (undoJson.Count == 0) { statusText.text = "Nothing to undo"; return; }
            redoJson.Push(UnityEngine.JsonUtility.ToJson(new ProjectData { items = new List<PlacedItem>(items) }));
            RestoreItems(UnityEngine.JsonUtility.FromJson<ProjectData>(undoJson.Pop()));
        }

        private void Redo()
        {
            if (redoJson.Count == 0) { statusText.text = "Nothing to redo"; return; }
            undoJson.Push(UnityEngine.JsonUtility.ToJson(new ProjectData { items = new List<PlacedItem>(items) }));
            RestoreItems(UnityEngine.JsonUtility.FromJson<ProjectData>(redoJson.Pop()));
        }

        private void RestoreItems(ProjectData data)
        {
            foreach (var item in stage.GetComponentsInChildren<DraggableFurniture>())
                Destroy(item.gameObject);
            items.Clear();
            foreach (var d in data.items)
            {
                AddFurniture(FindCatalogEntry(d.label, d.price));
                var f = Selected();
                if (f != null)
                {
                    var rt = f.GetComponent<RectTransform>();
                    rt.anchoredPosition = new Vector2(d.x, d.y);
                    rt.localScale = Vector3.one * Mathf.Max(.3f, d.scale);
                    f.transform.rotation = Quaternion.Euler(0,0,d.rotation);
                }
            }
            UpdateBudget();
        }

        private string ProjectPath
        {
            get
            {
                string dir = Path.Combine(Application.persistentDataPath, "InteriorVerse");
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                return Path.Combine(dir, "design.json");
            }
        }

        public void SaveProject()
        {
            ProjectData data = new ProjectData { items = new List<PlacedItem>(items) };
            File.WriteAllText(ProjectPath, UnityEngine.JsonUtility.ToJson(data, true));
            statusText.text = "Saved project JSON: " + ProjectPath;
        }

        public void LoadProject()
        {
            if (!File.Exists(ProjectPath)) { statusText.text = "No saved design found yet"; return; }
            RestoreItems(UnityEngine.JsonUtility.FromJson<ProjectData>(File.ReadAllText(ProjectPath)));
            statusText.text = "Design loaded from JSON";
        }

        private void LoadAutosaveIfPresent()
        {
            if (File.Exists(ProjectPath))
            {
                try { RestoreItems(UnityEngine.JsonUtility.FromJson<ProjectData>(File.ReadAllText(ProjectPath))); }
                catch (Exception ex) { Debug.LogWarning("InteriorVerse save could not be loaded: " + ex.Message); }
            }
        }

        private void ExportCSV()
        {
            string dir = Path.Combine(Application.persistentDataPath, "InteriorVerse", "Reports");
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, "InteriorVerse-Design.csv");
            using (StreamWriter writer = new StreamWriter(path, false))
            {
                writer.WriteLine("Name,Price,Position X,Position Y,Scale,Rotation Degrees");
                foreach (var i in items)
                    writer.WriteLine("\"" + i.label.Replace("\"","\"\"") + "\"," + i.price + "," + i.x + "," + i.y + "," + i.scale + "," + i.rotation);
                writer.WriteLine("Estimated total," + CalculateBudget());
            }
            statusText.text = "CSV exported: " + path;
        }

        private int CalculateBudget()
        {
            int total = 0;
            foreach (var item in items) total += item.price;
            return total;
        }

        private void UpdateBudget()
        {
            if (budgetText != null) budgetText.text = "EST. BUDGET: ₹" + CalculateBudget().ToString("N0");
        }

        private GameObject MakePanel(string name, Transform parent, Vector2 amin, Vector2 amax, Vector2 pivot, Vector2 size, Vector2 pos, Color color)
        {
            GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = amin; rt.anchorMax = amax; rt.pivot = pivot; rt.sizeDelta = size; rt.anchoredPosition = pos;
            go.GetComponent<Image>().color = color;
            return go;
        }

        private static Font cachedUIFont;

        private Text AddText(Transform parent, string value, int size, Vector2 amin, Vector2 amax, Vector2 pivot, Vector2 dimensions, Vector2 pos, Color color, TextAnchor align)
        {
            GameObject go = new GameObject("Text - " + value, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = amin; rt.anchorMax = amax; rt.pivot = pivot; rt.sizeDelta = dimensions; rt.anchoredPosition = pos;
            Text t = go.GetComponent<Text>();

            // Prefer the font bundled inside this project. This avoids Unity 6's removed
            // built-in Arial.ttf and avoids relying on fonts installed on the user's PC.
            if (cachedUIFont == null)
            {
                cachedUIFont = Resources.Load<Font>("InteriorVerseUI/DejaVuSans");
                if (cachedUIFont == null)
                    cachedUIFont = Font.CreateDynamicFontFromOSFont("Arial", Mathf.Max(16, size));
            }
            t.font = cachedUIFont;
            t.fontSize = Mathf.Max(size, 16);
            t.fontStyle = FontStyle.Bold;
            t.color = color;
            t.alignment = align;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.resizeTextForBestFit = true;
            t.resizeTextMinSize = 13;
            t.resizeTextMaxSize = Mathf.Max(size, 22);
            t.raycastTarget = false;
            t.maskable = false;
            t.supportRichText = false;
            return t;
        }

        private void MakeCatalogButton(Transform parent, CatalogEntry entry, Vector2 pos, Action action)
        {
            GameObject go = new GameObject("Catalog - " + entry.label, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.sizeDelta = new Vector2(284, 43);
            rt.anchoredPosition = pos;
            Image rowImage = go.GetComponent<Image>();
            rowImage.color = new Color(0.12f, 0.18f, 0.20f, 1f);
            Button button = go.GetComponent<Button>();
            button.targetGraphic = rowImage;
            button.onClick.AddListener(() => action());

            Texture2D texture = Resources.Load<Texture2D>("InteriorVerseFurniture/" + entry.resource);
            if (texture != null)
            {
                GameObject thumb = new GameObject("Furniture Thumbnail - " + entry.label, typeof(RectTransform), typeof(Image));
                thumb.transform.SetParent(go.transform, false);
                RectTransform tr = thumb.GetComponent<RectTransform>();
                tr.anchorMin = new Vector2(0, 0.5f); tr.anchorMax = new Vector2(0, 0.5f);
                tr.pivot = new Vector2(0, 0.5f); tr.sizeDelta = new Vector2(48, 38); tr.anchoredPosition = new Vector2(4, 0);
                Image ti = thumb.GetComponent<Image>();
                ti.sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
                ti.preserveAspect = true; ti.color = Color.white; ti.raycastTarget = false;
            }
            AddText(go.transform, entry.label + "\n₹" + entry.price.ToString("N0"), 17,
                new Vector2(0,0), new Vector2(1,1), new Vector2(0,0.5f),
                new Vector2(-62,-4), new Vector2(58,0), Color.white, TextAnchor.MiddleLeft);
        }

        private void MakeButton(Transform parent, string label, Vector2 amin, Vector2 amax, Vector2 pivot, Vector2 dimensions, Vector2 pos, Color color, Action action)
        {
            GameObject go = new GameObject("Button - " + label, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = amin; rt.anchorMax = amax; rt.pivot = pivot; rt.sizeDelta = dimensions; rt.anchoredPosition = pos;
            Image img = go.GetComponent<Image>(); img.color = color;
            Button b = go.GetComponent<Button>(); b.targetGraphic = img; b.onClick.AddListener(() => action());
            AddText(go.transform, label, 14, Vector2.zero, Vector2.one, new Vector2(.5f,.5f), Vector2.zero, Vector2.zero, Color.white, TextAnchor.MiddleCenter);
        }

        private void ToolButton(Transform parent, string label, Action action, ref float y, Color color)
        {
            MakeButton(parent, label, new Vector2(0,1), new Vector2(1,1), new Vector2(0,1),
                new Vector2(-24,46), new Vector2(12,y), color, action);
            y -= 50;
        }
    }

    public class DraggableFurniture : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler
    {
        [NonSerialized] public PhotoRoomDesigner designer;
        public string itemLabel;
        public int price;
        public float scale = 1f;
        public float rotation = 0f;
        public bool IsSelected { get; private set; }
        private Image image;
        private Vector2 dragOffset;

        private void Awake() { image = GetComponent<Image>(); }

        public void SetSelected(bool selected)
        {
            IsSelected = selected;
            if (image != null)
                image.color = selected ? new Color(image.color.r, image.color.g, image.color.b, 1f) : new Color(image.color.r, image.color.g, image.color.b, .86f);
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (designer != null) designer.Select(this);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (designer != null) designer.Select(this);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                transform.parent as RectTransform, eventData.position, eventData.pressEventCamera, out Vector2 point);
            dragOffset = GetComponent<RectTransform>().anchoredPosition - point;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                transform.parent as RectTransform, eventData.position, eventData.pressEventCamera, out Vector2 point))
            {
                RectTransform rt = GetComponent<RectTransform>();
                rt.anchoredPosition = point + dragOffset;
                if (designer != null) designer.UpdateItemPosition(this);
            }
        }

        public void OnEndDrag(PointerEventData eventData) { }
    }
}
