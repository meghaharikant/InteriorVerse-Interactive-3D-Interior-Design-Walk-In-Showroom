# InteriorVerse FINAL FIXED — Open This Project (Unity 6.5)

This is a standalone Unity 6.5 project with a sample room background, transparent furniture product thumbnails, and a labeled control panel. The left catalog shows a small furniture image plus the product name and estimated price. The right panel names each action directly (rotate left/right, make larger/smaller, save/load JSON, undo/redo, delete, export CSV, clear room).

## Open and run

1. Extract this ZIP. The extracted folder is named **InteriorVerse_FINAL_FIXED_OPEN_THIS_PROJECT**.
2. In Unity Hub, choose **Add > Add project from disk** and select that exact new folder. Do not open your older `InteriorVerse_Submission_Ready` project.
3. Open with Unity 6.5 (project metadata is set to 6000.5.10f1).
4. Wait for script compilation. The editor setup script creates `Assets/InteriorVerse/Scenes/InteriorVerse.unity`.
5. Press Play.

If the scene is not generated automatically, use **InteriorVerse > Generate Clean Photo Design Scene**.

## Add or replace the room background

A sample room photo is included at `Assets/InteriorVerse/Background/room.png`. Replace it with your own real JPG/PNG any time. You can copy your room photo to:
`Assets/InteriorVerse/Background/room.jpg`

PNG is also supported: `Assets/InteriorVerse/Background/room.png`.

If both files exist, the generated scene currently checks JPG first. After adding/replacing an image, let Unity import it, then select **InteriorVerse > Reload Room Photo From Folder**. If this is the first open and the scene has not yet been generated, use **InteriorVerse > Generate Clean Photo Design Scene**. The photo is loaded as a Unity texture asset, not decoded by runtime code, so no ImageConversion API is required.

## Runtime controls

- Left catalog: each row displays a real furniture PNG thumbnail, product name, and sample price. It includes two sofa styles, armchair, coffee table, cupboard, monstera, ficus tree, rug, door, floor lamp, bed, and dining set.
- Drag placed furniture overlays to position them over the photo.
- Click an item to select it.
- Right tools: save/load JSON, undo/redo, rotate, resize, delete, export CSV, clear design.
- Keyboard: F5 save, Ctrl+Z undo, Ctrl+Y redo, Delete selected.
- Saves: `Application.persistentDataPath/InteriorVerse/design.json`.
- CSV report: `Application.persistentDataPath/InteriorVerse/Reports/InteriorVerse-Design.csv`.

## Project scope / academic note

This is a photo-based 2D furniture staging tool: placed items are transparent furniture image overlays, not imported photorealistic 3D models. It is suitable as a photo staging demonstration. It does not infer depth, room geometry, collision, or real-world scale from a photograph. Those require manual calibration, segmented furniture sprites, or a 3D reconstruction. Prices are sample estimates and can be edited in `PhotoRoomDesigner.cs`.

## Important

This clean version excludes the previous unused scripts that were causing compilation errors. It has not been launched in a Unity Editor in this environment; after opening, check Console. If Unity's API/font settings differ, fix any resulting errors before submission.


## Error fixes in latest repair
- Added `scale` and `rotation` fields to `DraggableFurniture`.
- Fully qualified `UnityEngine.JsonUtility` references.
- Scene generation now checks that a background file exists before loading it.
- Do not rename a `.txt` file to `.jpg`; copy a real JPEG or PNG image into the Background folder. The project runs with no image too, using a plain dark canvas until a real image is added.


### JSON serialization module
The project manifest explicitly includes Unity's `com.unity.modules.jsonserialize` built-in module because the save/load feature uses `UnityEngine.JsonUtility`. If Unity Hub already has an older copy open, close it and open this repaired project folder so Package Manager reads the updated manifest.

### Unity 6.5 built-in font fix
The UI now requests `LegacyRuntime.ttf` rather than the removed `Arial.ttf` built-in font, resolving the runtime ArgumentException shown in the Console.


## Latest usability fixes
- Catalog now uses individual transparent furniture images with distinct variants (two sofas, armchair, coffee table, sideboard, monstera, ficus tree, rug, door, lamp, bed, dining set).
- Room photo import menu validates a real image before copying it into the project.
- Use **InteriorVerse > Import Room Photo...** to choose an image from anywhere on your computer.
- To replace a photo later, use **InteriorVerse > Import Room Photo...** again, or place a valid `room.jpg`/`room.png` in `Assets/InteriorVerse/Background/` and choose **InteriorVerse > Reload Room Photo From Folder**.
- Scene generation/import/reload now refuses to run during Play mode to avoid Unity's `NewScene cannot be used during play mode` exception.
- Furniture visuals are 2D image overlays on the photo, not 3D reconstructed models.

- Updated the remaining deprecated `FindObjectOfType` call in `PhotoRoomDesigner.cs` to `FindAnyObjectByType` for Unity 6.5.


## UI label fix
The project bundles DejaVu Sans under `Assets/Resources/InteriorVerseUI/DejaVuSans.ttf` so it does not depend on Unity legacy fonts. Catalog rows include transparent furniture thumbnails. Tool buttons are wider, use readable bold labels, and separately identify left/right rotation. If the screen still looks unchanged, check the Unity title bar and confirm the project folder is `InteriorVerse_FINAL_FIXED_OPEN_THIS_PROJECT`, not the older `InteriorVerse_Submission_Ready` folder.


## Unity 6 Walk-in Showroom (new)
This ZIP now includes a native Unity scene generator and scripts under `Assets/InteriorVerse/WalkInShowroom/`. Open the project in Unity 6, then choose **InteriorVerse → Build Unity 6 Walk-in Showroom** and press Play. See `Documentation/UNITY6_WALK_IN_SHOWROOM_GUIDE.md` for setup and controls. The generated 3D scene has living room, bedroom, bathroom and kitchen collections, lighting moods, walk controls and product inspection. It does not depend on the separate browser demo.


### Important Unity menu note
For the walk-in 3D showroom, stop Play mode first and use **InteriorVerse → Build Unity 6 Walk-in Showroom**. Do not select the older **Generate Clean Photo Design Scene** menu item. The walk-in camera is configured to face into the room at startup.

## Latest material/detail upgrade
See `Documentation/PHOTOREALISM_UPGRADE_NOTES.md` for the procedural material texture improvements, furniture-detail additions, setup steps, and limitations. This remains a prototype; it has not been runtime-tested in Unity as part of this ZIP update.
