# CS4104 Case Study 3 — InteriorVerse Photo-Based Furniture Staging

## Problem
An interior-design startup needs a lightweight interface for testing furniture arrangements against photographs of customer rooms before purchase.

## Proposed solution
InteriorVerse provides a photo-backed design canvas, selectable catalog overlays, drag placement, rotate/scale/delete operations, undo/redo, JSON save/load, budget estimation, and CSV reporting.

## Computer graphics concepts
- Screen-space composition using a full-screen UI canvas and background texture.
- 2D coordinate mapping from pointer screen coordinates to canvas-local coordinates.
- Alpha compositing for furniture overlays.
- Object transform operations: translation, rotation, uniform scaling.
- Texture filtering and aspect-ratio considerations for background imagery.

## Why photo staging
It keeps the project easy to run and lets a user change the room image by replacing one asset. Unlike 3D AR reconstruction, the photo-only version cannot determine hidden geometry or physically accurate depth. The case study explicitly documents this limitation rather than claiming depth-aware collision on a 2D image.

## Performance
The design uses UI rectangles and text, avoiding complex real-time 3D geometry. This reduces draw and simulation cost. A production version should use sprite atlases, pooled UI items, compressed textures, and target-device profiling.

## Evaluation plan
1. Replace room.jpg and verify the new image is shown.
2. Add at least five furniture categories.
3. Drag and rotate objects to produce a layout.
4. Save and reload the JSON design.
5. Export CSV and compare item count and total price.
6. Record frame rate and test at common window aspect ratios.


## Updated UI
The furniture catalog displays individual PNG thumbnails with names and estimated prices. The right panel labels the operation of each control, including separate rotate-left and rotate-right actions, smaller/larger actions, JSON save/load, undo/redo, delete, CSV export, and clear room.
