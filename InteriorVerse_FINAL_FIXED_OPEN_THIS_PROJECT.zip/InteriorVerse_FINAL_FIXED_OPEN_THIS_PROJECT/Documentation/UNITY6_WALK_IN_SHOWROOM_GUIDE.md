# InteriorVerse — Unity 6 Walk-in Showroom

## What is included
- Native Unity 3D walk-in scene generated from C# (not the HTML WebXR demo).
- Four room collections: Living Room, Bedroom, Bathroom and Kitchen.
- Procedural room shell, window, wood floor, wall art, furniture, bathroom fixtures and kitchen units.
- Daylight and warm-evening lighting moods, soft shadows, ambient fill and roughness/metalness material settings.
- Runtime UI for room switching, lighting changes, navigation hints and product details.
- A setup menu item that creates and saves the scene and enables it in Build Settings.
- Original InteriorVerse photo-room designer and supplied room background image are retained.

## Open in Unity 6
1. Extract the ZIP to a normal writable folder.
2. Open Unity Hub → **Add** → **Add project from disk**.
3. Choose the `InteriorVerse_FINAL_FIXED_OPEN_THIS_PROJECT` folder (the one containing `Assets`, `Packages` and `ProjectSettings`).
4. Open with Unity 6. Let Unity finish importing scripts.
5. From the top menu, choose **InteriorVerse → Build Unity 6 Walk-in Showroom**.
6. Press **Play**.

## Controls
- **W / A / S / D** or arrow keys: walk.
- **Right-click and move the mouse**: look around; the mouse locks while looking.
- **Esc**: release the mouse.
- **Left-click**: inspect the product at the center of the view.
- Use the on-screen buttons to change room and lighting.

## Build an executable
1. Open **File → Build Profiles** (or **File → Build Settings**, depending on Unity 6 release).
2. Confirm `Assets/InteriorVerse/Scenes/InteriorVerse_WalkInShowroom.unity` is listed and enabled.
3. Choose your target platform, click **Switch Platform** if required, then **Build**.

## Technical note
This is a Unity-native procedural prototype and does not require external assets or packages for the generated scene. The provided original room photo remains available to the photo-room designer. The walk-in scene builds a 3D room environment rather than using a flat image as the whole background, because a static photo cannot support natural walk-around navigation. Geometry/materials are starter assets; replace them with licensed high-quality FBX/GLB furniture models and scanned PBR textures for production-level realism. WebXR headset or mobile AR deployment is a separate setup and is not automatically enabled by this desktop scene.

## Assignment concepts
- **Illumination and colour:** ambient/trilight fill plus directional sunlight; material colour, smoothness/roughness and metallic response affect the appearance of velvet, leather, ceramic and brass.
- **Texture/bump mapping:** materials are organized so proper albedo, normal/bump and roughness maps can be assigned later without increasing mesh polygon count.
- **Window-to-viewport:** Unity's camera projection maps world-space geometry to viewport pixels; the screen-center ray is used for product selection, while the responsive CanvasScaler adapts UI layout to different display sizes.
